// Argomenti per classe e materia, ordinati come un anno scolastico.
// Riferimento: classi prime dal 2026/27 -> Nuove Indicazioni Nazionali (D.M. 2025);
// classi 2ª-5ª -> Indicazioni Nazionali 2012, fino al passaggio graduale.
// Per collegare una lezione pronta basta aggiungere `lezione: "lezioni/nome-file.json"`.
// Con `evidenza: true` la scheda compare in grande, con il nastro "In evidenza".

window.SITO = {
  nome: "La classe di Irene",
  motto: "Matematica e Scienze per piccoli esploratori",
  // Classi in cui Irene insegna quest'anno: in evidenza nella home.
  classiInEvidenza: [2, 4],
};

window.MATERIE = {
  matematica: { nome: "Matematica", icona: "🔢", classe: "matematica" },
  scienze: { nome: "Scienze", icona: "🔬", classe: "scienze" },
};

window.RIFERIMENTO = function (classe) {
  return classe === 1
    ? "Nuove Indicazioni Nazionali (in vigore per le classi prime dal 2026/27)"
    : "Indicazioni Nazionali 2012 (in vigore per questa classe nel 2026/27)";
};

window.CURRICOLO = {
  matematica: {
    1: [
      { id: "mat1-insiemi", emoji: "🧺", titolo: "Classificare e raggruppare", descrizione: "Insiemi, uguale e diverso, di più e di meno.", lezione: "lezioni/mat1-classificare-e-raggruppare.json" },
      { id: "mat1-numeri20", emoji: "🔢", titolo: "I numeri fino a 20", descrizione: "Contare, leggere, scrivere e ordinare i numeri.", lezione: "lezioni/mat1-numeri-fino-a-20.json" },
      { id: "mat1-confronto", emoji: "⚖️", titolo: "Maggiore, minore, uguale", descrizione: "Confrontare quantità e numeri con > < =.", lezione: "lezioni/mat1-maggiore-minore-uguale.json" },
      { id: "mat1-decina", emoji: "🔟", titolo: "La decina", descrizione: "Raggruppare per dieci: decine e unità.", lezione: "lezioni/mat1-la-decina.json" },
      { id: "mat1-addizione", emoji: "➕", titolo: "L'addizione", descrizione: "Aggiungere e unire, sulla linea dei numeri.", lezione: "lezioni/mat1-l-addizione.json" },
      { id: "mat1-sottrazione", emoji: "➖", titolo: "La sottrazione", descrizione: "Togliere e trovare la differenza.", lezione: "lezioni/mat1-la-sottrazione.json" },
      { id: "mat1-spazio", emoji: "🧭", titolo: "Sopra, sotto, destra, sinistra", descrizione: "Orientarsi nello spazio e sul foglio.", lezione: "lezioni/mat1-sopra-sotto-destra-sinistra.json" },
      { id: "mat1-forme", emoji: "🔺", titolo: "Le forme intorno a noi", descrizione: "Cerchio, quadrato, triangolo, rettangolo.", lezione: "lezioni/mat1-le-forme.json" },
      { id: "mat1-problemi", emoji: "🧩", titolo: "Piccoli problemi", descrizione: "Raccontare e risolvere situazioni con i numeri.", lezione: "lezioni/mat1-piccoli-problemi.json" },
      { id: "mat1-algoritmi", emoji: "🤖", titolo: "Istruzioni in fila", descrizione: "Primi algoritmi: seguire e dare comandi in ordine.", lezione: "lezioni/mat1-istruzioni-in-fila.json" },
    ],
    2: [
      { id: "mat2-numeri100", emoji: "💯", titolo: "I numeri fino a 100", descrizione: "Decine e unità, valore posizionale.", lezione: "lezioni/mat2-numeri-fino-a-100.json" },
      { id: "mat2-addcambio", emoji: "➕", titolo: "Addizioni in colonna", descrizione: "Con e senza cambio.", lezione: "lezioni/mat2-addizioni-in-colonna.json" },
      { id: "mat2-sottcambio", emoji: "➖", titolo: "Sottrazioni in colonna", descrizione: "Con e senza prestito.", lezione: "lezioni/mat2-sottrazioni-in-colonna.json" },
      { id: "mat2-moltiplicazione", emoji: "✖️", titolo: "La moltiplicazione", descrizione: "Addizioni ripetute e schieramenti.", lezione: "lezioni/mat2-la-moltiplicazione.json" },
      { id: "mat2-tabelline", emoji: "🎶", titolo: "Le tabelline", descrizione: "Dalla tabellina del 2 a quella del 10.", lezione: "lezioni/mat2-le-tabelline.json" },
      { id: "mat2-divisione", emoji: "🍕", titolo: "Dividere in parti uguali", descrizione: "Distribuire e raggruppare.", lezione: "lezioni/mat2-dividere-in-parti-uguali.json" },
      { id: "mat2-pari", emoji: "👯", titolo: "Pari e dispari", descrizione: "Riconoscere i numeri pari e dispari.", lezione: "lezioni/mat2-pari-e-dispari.json" },
      { id: "mat2-linee", emoji: "〰️", titolo: "Linee e confini", descrizione: "Linee aperte, chiuse, regioni interne ed esterne.", lezione: "lezioni/mat2-linee-e-confini.json" },
      { id: "mat2-misure", emoji: "📏", titolo: "Misurare con il corpo", descrizione: "Misure arbitrarie: spanne, passi, matite.", lezione: "lezioni/mat2-misurare-con-il-corpo.json" },
      { id: "mat2-euro", emoji: "💶", titolo: "Le monete e l'euro", descrizione: "Contare soldi e fare la spesa.", lezione: "lezioni/mat2-le-monete-e-l-euro.json" },
    ],
    3: [
      { id: "mat3-migliaia", emoji: "🏰", titolo: "I numeri fino a 1000", descrizione: "Centinaia, decine, unità.", lezione: "lezioni/mat3-numeri-fino-a-1000.json" },
      { id: "mat3-operazioni", emoji: "🧮", titolo: "Le quattro operazioni", descrizione: "Proprietà e calcolo in colonna.", lezione: "lezioni/mat3-le-quattro-operazioni.json" },
      { id: "mat3-divisione", emoji: "➗", titolo: "La divisione in colonna", descrizione: "Con una cifra al divisore, con il resto.", lezione: "lezioni/mat3-la-divisione-in-colonna.json" },
      { id: "mat3-frazioni", emoji: "🍰", titolo: "Le frazioni", descrizione: "L'intero diviso in parti uguali.", lezione: "lezioni/mat3-le-frazioni.json" },
      { id: "mat3-decimali", emoji: "🔸", titolo: "Decimi e centesimi", descrizione: "Primi numeri decimali.", lezione: "lezioni/mat3-decimi-e-centesimi.json" },
      { id: "mat3-angoli", emoji: "📐", titolo: "Gli angoli", descrizione: "Retto, acuto, ottuso.", lezione: "lezioni/mat3-gli-angoli.json" },
      { id: "mat3-poligoni", emoji: "🔷", titolo: "I poligoni", descrizione: "Lati, vertici e perimetro.", lezione: "lezioni/mat3-i-poligoni.json" },
      { id: "mat3-misure", emoji: "📏", titolo: "Le misure di lunghezza", descrizione: "Metro, multipli e sottomultipli.", lezione: "lezioni/mat3-le-misure-di-lunghezza.json" },
      { id: "mat3-dati", emoji: "📊", titolo: "Indagini e grafici", descrizione: "Raccogliere dati e fare istogrammi.", lezione: "lezioni/mat3-indagini-e-grafici.json" },
      { id: "mat3-problemi", emoji: "🧩", titolo: "Problemi con due domande", descrizione: "Dati, domanda, operazioni.", lezione: "lezioni/mat3-problemi-con-due-domande.json" },
    ],
    4: [
      { id: "mat4-divisioni-una", emoji: "➗", titolo: "Divisioni a una cifra", descrizione: "La filastrocca della divisione: cappellino, tabellina, resto e ascensore.", lezione: "lezioni/mat4-divisioni-una-cifra.json", evidenza: true },
      { id: "mat4-divisioni", emoji: "➗", titolo: "Divisioni a due cifre", descrizione: "Divisore a due cifre e prova.", lezione: "lezioni/mat4-divisioni-due-cifre.json" },
      { id: "mat4-grandi", emoji: "🚀", titolo: "I grandi numeri", descrizione: "Migliaia e classi di numeri.", lezione: "lezioni/mat4-grandi-numeri.json" },
      { id: "mat4-scomporre", emoji: "🧩", titolo: "Scomporre e comporre", descrizione: "Quanto vale ogni cifra; lo 0 segnaposto.", lezione: "lezioni/mat4-scomporre-e-comporre.json" },
      { id: "mat4-confronto", emoji: "🐊", titolo: "Il confronto tra numeri", descrizione: "Maggiore, minore, uguale; crescente e decrescente.", lezione: "lezioni/mat4-confronto-tra-numeri.json" },
      { id: "mat4-successione", emoji: "🐸", titolo: "Numeri in successione", descrizione: "Numeri in fila, crescente e decrescente, pari e dispari, la regola dei salti.", lezione: "lezioni/mat4-numeri-in-successione.json" },
      { id: "mat4-equivalenze", emoji: "🔄", titolo: "Le equivalenze con i numeri", descrizione: "Unità, decine, centinaia e migliaia.", lezione: "lezioni/mat4-equivalenze-numeriche.json" },
      { id: "mat4-relazione", emoji: "⚖️", titolo: "La relazione di equivalenza", descrizione: "Tabella hk, dak, uk, h, da, u e virgola.", lezione: "lezioni/mat4-relazione-di-equivalenza.json" },
      { id: "mat4-moltiplicazioni", emoji: "✖️", titolo: "Moltiplicazioni a due cifre", descrizione: "Calcolo in colonna e stime.", lezione: "lezioni/mat4-moltiplicazioni-due-cifre.json" },
      { id: "mat4-frazioni", emoji: "🍕", titolo: "Frazioni proprie e improprie", descrizione: "Frazioni equivalenti e complementari.", lezione: "lezioni/mat4-frazioni.json" },
      { id: "mat4-decimali", emoji: "🔸", titolo: "I numeri decimali", descrizione: "Operazioni con i decimali.", lezione: "lezioni/mat4-numeri-decimali.json" },
      { id: "mat4-perimetro", emoji: "🟩", titolo: "Perimetro dei poligoni", descrizione: "Triangoli e quadrilateri.", lezione: "lezioni/mat4-perimetro.json" },
      { id: "mat4-area", emoji: "🧱", titolo: "Il concetto di area", descrizione: "Superfici equiestese e unità di misura.", lezione: "lezioni/mat4-area.json" },
      { id: "mat4-misure", emoji: "⚖️", titolo: "Peso e capacità", descrizione: "Chilogrammo, litro, multipli e sottomultipli.", lezione: "lezioni/mat4-peso-e-capacita.json" },
      { id: "mat4-probabilita", emoji: "🎲", titolo: "Certo, possibile, impossibile", descrizione: "Primi passi nella probabilità.", lezione: "lezioni/mat4-certo-possibile-impossibile.json" },
      { id: "mat4-problemi", emoji: "🧩", titolo: "Problemi con le misure", descrizione: "Peso lordo, netto, tara e compravendita.", lezione: "lezioni/mat4-problemi-con-le-misure.json" },
    ],
    5: [
      { id: "mat5-milioni", emoji: "🌌", titolo: "Milioni e miliardi", descrizione: "Numeri grandissimi e potenze.", lezione: "lezioni/mat5-milioni.json" },
      { id: "mat5-potenze", emoji: "⚡", titolo: "Le potenze", descrizione: "Base, esponente e notazione.", lezione: "lezioni/mat5-potenze.json" },
      { id: "mat5-multipli", emoji: "🔗", titolo: "Multipli, divisori e primi", descrizione: "Criteri di divisibilità.", lezione: "lezioni/mat5-multipli.json" },
      { id: "mat5-decimali", emoji: "🔸", titolo: "I numeri decimali", descrizione: "Decimi, centesimi, millesimi; per e diviso 10, 100, 1000.", lezione: "lezioni/mat5-numeri-decimali.json" },
      { id: "mat5-relativi", emoji: "🌡️", titolo: "I numeri negativi", descrizione: "Temperature e retta dei numeri relativi.", lezione: "lezioni/mat5-relativi.json" },
      { id: "mat5-percentuali", emoji: "💯", titolo: "Le percentuali", descrizione: "Sconti, aumenti e frazioni.", lezione: "lezioni/mat5-le-percentuali.json" },
      { id: "mat5-aree", emoji: "📐", titolo: "Area dei poligoni", descrizione: "Formule per triangoli e quadrilateri.", lezione: "lezioni/mat5-area-dei-poligoni.json" },
      { id: "mat5-cerchio", emoji: "⭕", titolo: "Il cerchio", descrizione: "Circonferenza, raggio, diametro.", lezione: "lezioni/mat5-il-cerchio.json" },
      { id: "mat5-solidi", emoji: "🧊", titolo: "I solidi", descrizione: "Sviluppi e volume.", lezione: "lezioni/mat5-i-solidi.json" },
      { id: "mat5-statistica", emoji: "📊", titolo: "Media, moda, mediana", descrizione: "Leggere e interpretare dati.", lezione: "lezioni/mat5-media-moda-mediana.json" },
      { id: "mat5-espressioni", emoji: "🧠", titolo: "Le espressioni", descrizione: "Ordine delle operazioni e parentesi.", lezione: "lezioni/mat5-le-espressioni.json" },
    ],
  },
  scienze: {
    1: [
      { id: "sci1-sensi", emoji: "👀", titolo: "I cinque sensi", descrizione: "Esplorare il mondo con vista, udito, tatto, gusto, olfatto.", lezione: "lezioni/sci1-i-cinque-sensi.json" },
      { id: "sci1-corpo", emoji: "🧍", titolo: "Il mio corpo", descrizione: "Le parti del corpo e come muoversi.", lezione: "lezioni/sci1-il-mio-corpo.json" },
      { id: "sci1-viventi", emoji: "🌱", titolo: "Viventi e non viventi", descrizione: "Che cosa nasce, cresce e si riproduce?", lezione: "lezioni/sci1-viventi-e-non-viventi.json" },
      { id: "sci1-oggetti", emoji: "🧸", titolo: "Gli oggetti e i materiali", descrizione: "Legno, plastica, metallo, carta, vetro.", lezione: "lezioni/sci1-gli-oggetti-e-i-materiali.json" },
      { id: "sci1-stagioni", emoji: "🍂", titolo: "Le stagioni", descrizione: "Come cambia la natura durante l'anno.", lezione: "lezioni/sci1-le-stagioni.json" },
      { id: "sci1-tempo", emoji: "☀️", titolo: "Che tempo fa?", descrizione: "Sole, pioggia, vento, neve.", lezione: "lezioni/sci1-che-tempo-fa.json" },
      { id: "sci1-piante", emoji: "🌻", titolo: "Le piante del giardino", descrizione: "Radici, fusto, foglie e fiori.", lezione: "lezioni/sci1-le-piante-del-giardino.json" },
      { id: "sci1-animali", emoji: "🐾", titolo: "Gli animali intorno a noi", descrizione: "Dove vivono e come si muovono.", lezione: "lezioni/sci1-gli-animali-intorno-a-noi.json" },
    ],
    2: [
      { id: "sci2-materia", emoji: "🧊", titolo: "Solidi, liquidi e gas", descrizione: "Gli stati della materia.", lezione: "lezioni/sci2-solidi-liquidi-gas.json" },
      { id: "sci2-acqua", emoji: "💧", titolo: "L'acqua", descrizione: "Proprietà e trasformazioni dell'acqua.", lezione: "lezioni/sci2-l-acqua.json" },
      { id: "sci2-semi", emoji: "🌰", titolo: "Dal seme alla pianta", descrizione: "La germinazione e la crescita.", lezione: "lezioni/sci2-dal-seme-alla-pianta.json" },
      { id: "sci2-ciclovita", emoji: "🔄", titolo: "Il ciclo della vita", descrizione: "Nascere, crescere, riprodursi, morire.", lezione: "lezioni/sci2-il-ciclo-della-vita.json" },
      { id: "sci2-animali", emoji: "🦁", titolo: "Classificare gli animali", descrizione: "Cosa mangiano, come nascono, come si muovono.", lezione: "lezioni/sci2-classificare-gli-animali.json" },
      { id: "sci2-ambienti", emoji: "🏞️", titolo: "Gli ambienti naturali", descrizione: "Bosco, prato, mare, montagna.", lezione: "lezioni/sci2-gli-ambienti-naturali.json" },
      { id: "sci2-rifiuti", emoji: "♻️", titolo: "La raccolta differenziata", descrizione: "Rispettare l'ambiente.", lezione: "lezioni/sci2-la-raccolta-differenziata.json" },
      { id: "sci2-esperimenti", emoji: "🧪", titolo: "Il metodo dello scienziato", descrizione: "Osservare, fare ipotesi, provare.", lezione: "lezioni/sci2-il-metodo-dello-scienziato.json" },
    ],
    3: [
      { id: "sci3-metodo", emoji: "🔬", titolo: "Il metodo scientifico", descrizione: "Domanda, ipotesi, esperimento, conclusione.", lezione: "lezioni/sci3-il-metodo-scientifico.json" },
      { id: "sci3-materia", emoji: "⚛️", titolo: "La materia e i suoi stati", descrizione: "Passaggi di stato.", lezione: "lezioni/sci3-la-materia-e-i-suoi-stati.json" },
      { id: "sci3-acqua", emoji: "🌧️", titolo: "Il ciclo dell'acqua", descrizione: "Evaporazione, condensazione, precipitazione.", lezione: "lezioni/sci3-ciclo-dell-acqua.json" },
      { id: "sci3-aria", emoji: "🌬️", titolo: "L'aria", descrizione: "Proprietà dell'aria e il vento.", lezione: "lezioni/sci3-l-aria.json" },
      { id: "sci3-suolo", emoji: "🪱", titolo: "Il suolo", descrizione: "Strati del terreno e piccoli abitanti.", lezione: "lezioni/sci3-il-suolo.json" },
      { id: "sci3-piante", emoji: "🌿", titolo: "Le piante", descrizione: "Parti della pianta e fotosintesi.", lezione: "lezioni/sci3-le-piante.json" },
      { id: "sci3-animali", emoji: "🐸", titolo: "Vertebrati e invertebrati", descrizione: "Classificare il regno animale.", lezione: "lezioni/sci3-vertebrati-e-invertebrati.json" },
      { id: "sci3-catene", emoji: "🦊", titolo: "Le catene alimentari", descrizione: "Produttori, consumatori, decompositori.", lezione: "lezioni/sci3-le-catene-alimentari.json" },
    ],
    4: [
      { id: "sci4-cellula", emoji: "🧫", titolo: "La cellula", descrizione: "Cellula animale e cellula vegetale.", lezione: "lezioni/sci4-la-cellula.json" },
      { id: "sci4-regni", emoji: "🍄", titolo: "I cinque regni", descrizione: "Batteri, protisti, funghi, piante, animali.", lezione: "lezioni/sci4-cinque-regni.json" },
      { id: "sci4-piante", emoji: "🌸", titolo: "Riproduzione delle piante", descrizione: "Fiore, impollinazione, frutto e seme.", lezione: "lezioni/sci4-riproduzione-piante.json" },
      { id: "sci4-invertebrati", emoji: "🐝", titolo: "Gli invertebrati", descrizione: "Insetti, molluschi, aracnidi...", lezione: "lezioni/sci4-gli-invertebrati.json" },
      { id: "sci4-vertebrati", emoji: "🐬", titolo: "I vertebrati", descrizione: "Pesci, anfibi, rettili, uccelli, mammiferi.", lezione: "lezioni/sci4-i-vertebrati.json" },
      { id: "sci4-ecosistemi", emoji: "🌳", titolo: "Gli ecosistemi", descrizione: "Equilibri tra viventi e ambiente.", lezione: "lezioni/sci4-gli-ecosistemi.json" },
      { id: "sci4-calore", emoji: "🔥", titolo: "Calore e temperatura", descrizione: "Il termometro e la dilatazione.", lezione: "lezioni/sci4-calore-e-temperatura.json" },
      { id: "sci4-miscugli", emoji: "🥣", titolo: "Miscugli e soluzioni", descrizione: "Separare e sciogliere.", lezione: "lezioni/sci4-miscugli-e-soluzioni.json" },
    ],
    5: [
      { id: "sci5-corpo", emoji: "🫀", titolo: "Il corpo umano", descrizione: "Organi, apparati e sistemi.", lezione: "lezioni/sci5-corpo-umano.json" },
      { id: "sci5-digerente", emoji: "🍎", titolo: "Apparato digerente", descrizione: "Il viaggio del cibo.", lezione: "lezioni/sci5-digerente.json" },
      { id: "sci5-respiratorio", emoji: "🫁", titolo: "Respiratorio e circolatorio", descrizione: "Polmoni, cuore e sangue.", lezione: "lezioni/sci5-respiratorio.json" },
      { id: "sci5-nervoso", emoji: "🧠", titolo: "Il sistema nervoso", descrizione: "Cervello, nervi e sensi.", lezione: "lezioni/sci5-nervoso.json" },
      { id: "sci5-salute", emoji: "🥗", titolo: "Alimentazione e salute", descrizione: "La piramide alimentare e i corretti stili di vita.", lezione: "lezioni/sci5-alimentazione-e-salute.json" },
      { id: "sci5-energia", emoji: "⚡", titolo: "L'energia", descrizione: "Fonti rinnovabili e non rinnovabili.", lezione: "lezioni/sci5-l-energia.json" },
      { id: "sci5-luce", emoji: "🌈", titolo: "Luce e suono", descrizione: "Come viaggiano luce e suono.", lezione: "lezioni/sci5-luce-e-suono.json" },
      { id: "sci5-universo", emoji: "🪐", titolo: "Il Sistema solare", descrizione: "Il Sole, i pianeti e la Luna.", lezione: "lezioni/sci5-il-sistema-solare.json" },
    ],
  },
};
